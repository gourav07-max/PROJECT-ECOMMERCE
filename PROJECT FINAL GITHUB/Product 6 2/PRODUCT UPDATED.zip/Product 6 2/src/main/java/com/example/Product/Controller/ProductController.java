package com.example.Product.Controller;


import com.example.Product.Entity.ProductEntity;
import com.example.Product.Services.ProductService;
import com.example.Product.dto.MerchantProduct;
import com.example.Product.dto.Product;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/product")
@Valid
public class ProductController {


    @Autowired
    ProductService productService;


  @CrossOrigin(origins = "http://localhost:8080")
    @GetMapping("/products")
    public List<MerchantProduct> getAllProducts(){

        return productService.getAll();
    }



    @GetMapping("/productbycategory")
    List<MerchantProduct> getCategories(@RequestParam(required = true) String category){

        return productService.getByCategory(category);
    }

    @GetMapping("/byId")
    public ProductEntity getProductById(@RequestParam(required = true) Integer id){
        return productService.getProductById(id);
    }

    @PostMapping(produces = "application/json")
    public void add(@RequestBody @Valid MerchantProduct product){
        productService.adds(product);

    }

    @PutMapping(produces = "applicatin/json")
    public void put(@RequestBody @Valid MerchantProduct product){
        productService.update(product);
    }

    @DeleteMapping(produces = "application/json")
    public void delete(){
        productService.delete();
    }




}
