package com.example.Product.Services;


import com.example.Product.Entity.ProductEntity;
import com.example.Product.Repository.ProductRepository;
import com.example.Product.dto.MerchantProduct;
import com.example.Product.dto.Product;
import com.example.Product.fiegn.MerchantInterface;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class ProductServiceImpl implements ProductService  {


    @Autowired
    ProductRepository productRepository;

    @Autowired
    MerchantInterface merchantInterface;


    List<ProductEntity> productEntityList=new ArrayList<>();




    public List<MerchantProduct> getAll() {
        Iterable<ProductEntity> productEntities=productRepository.findAll();
        List<MerchantProduct> productList=new ArrayList<>();
        for(ProductEntity productEntity:productEntities){
          try{
            MerchantProduct product=new MerchantProduct(productEntity.getMerchantid(),productEntity.getProductId(),productEntity.getPrice(),productEntity.getStocks(),productEntity.getName(),productEntity.getDescription(),productEntity.getCatogoryName(),productEntity.getMerchantname(),productEntity.getImgurl());
            productList.add(product);}
            catch (Exception e){
                System.out.println(e);
            }
        }
        return productList;
    }




    public List<MerchantProduct> getByCategory(String category) {

        return productRepository.findBycatogoryName(category);

    }




    public void update(MerchantProduct product)
    {

        ProductEntity  productEntity= productRepository.findByproductId(product.getProductId());
        System.out.println(productEntity);
        productEntity.setProductId(product.getProductId());
        productEntity.setName(product.getName());
        productEntity.setDescription(product.getDescription());
        productEntity.setImgurl(product.getImgurl());
        productEntity.setMerchantid(product.getMerchantid());
        productEntity.setMerchantname(product.getMerchantname());
        productEntity.setCatogoryName(product.getCatogoryName());
        productEntity.setPrice(product.getPrice());

        productRepository.save(productEntity);

            }


    public void delete(){


      List<Integer> name =merchantInterface.deleteProduct();
      for(Integer i:name){
          productRepository.deleteByproductId(i);
      }


   }



    public void adds(MerchantProduct product){

        List<ProductEntity> productList =productRepository.findByname(product.getName());
ProductEntity productEntity=new ProductEntity();
        if(productList.size()==0) {
            productEntity.setProductId(product.getProductId());
            productEntity.setName(product.getName());
            productEntity.setDescription(product.getDescription());
            productEntity.setImgurl(product.getImgurl());
            productEntity.setMerchantid(product.getMerchantid());
            productEntity.setMerchantname(product.getMerchantname());
            productEntity.setCatogoryName(product.getCatogoryName());
            productEntity.setPrice(product.getPrice());
            productEntity.setStocks(product.getStock());
            productRepository.save(productEntity);


            MerchantProduct merchantProduct=new MerchantProduct(product.getMerchantid(),product.getProductId(),product.getPrice(),product.getStock(),product.getName(),product.getDescription(),product.getCatogoryName(),product.getMerchantname(),product.getImgurl());
            merchantInterface.add(merchantProduct);

        }

        else if(productList.size()!=0){

            for(ProductEntity i:productList){
                if(i.getPrice()>product.getPrice()){

                // ProductEntity temp = productRepository.findByproductId(i.getProductId());
                 //productRepository.deleteByproductId(i.getProductId());
                 //   System.out.println("in loop");
                    i.setProductId(product.getProductId());
                    i.setName(product.getName());
                    i.setDescription(product.getDescription());
                    i.setImgurl(product.getImgurl());
                    i.setMerchantid(product.getMerchantid());
                    i.setMerchantname(product.getMerchantname());
                    i.setCatogoryName(product.getCatogoryName());
                    i.setPrice(product.getPrice());

                    productRepository.save(i);

                    MerchantProduct merchantProduct=new MerchantProduct(product.getMerchantid(),product.getProductId(),product.getPrice(),product.getStock(),product.getName(),product.getDescription(),product.getCatogoryName(),product.getMerchantname(),product.getImgurl());
                    merchantInterface.add(merchantProduct);

                }

                else{
                  //  System.out.println("in fiegn");
                    MerchantProduct merchantProduct=new MerchantProduct(product.getMerchantid(),product.getProductId(),product.getPrice(),product.getStock(),product.getName(),product.getDescription(),product.getCatogoryName(),product.getMerchantname(),product.getImgurl());
                    merchantInterface.add(merchantProduct);
                }

            }
        }





    }



    @Override
    public ProductEntity getProductById(Integer id)
    {
        try {
            return productRepository.findByproductId(id);
        }
        catch (Exception e){
            System.out.println("Id not present");
            return null;
        }
    }




}
