package com.example.Postgresql.repository;

import com.example.Postgresql.entity.CartEntity;
import com.example.Postgresql.entity.UserHistoryEntity;
import org.springframework.data.repository.CrudRepository;

public interface UserHistoryRepository extends CrudRepository<UserHistoryEntity,Integer> {
}
