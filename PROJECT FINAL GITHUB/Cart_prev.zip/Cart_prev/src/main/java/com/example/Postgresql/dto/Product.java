package com.example.Postgresql.dto;

public class Product {

}
