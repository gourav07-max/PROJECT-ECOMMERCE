package com.example.Postgresql;

import org.junit.jupiter.api.Test;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CartTests {

	@Test
	void contextLoads() {
	}

}
