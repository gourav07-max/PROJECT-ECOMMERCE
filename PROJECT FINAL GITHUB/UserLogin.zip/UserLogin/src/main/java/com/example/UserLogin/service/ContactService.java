package com.example.UserLogin.service;

import com.example.UserLogin.dto.Contact;

public interface ContactService {

    void submit(Contact contact);
}
